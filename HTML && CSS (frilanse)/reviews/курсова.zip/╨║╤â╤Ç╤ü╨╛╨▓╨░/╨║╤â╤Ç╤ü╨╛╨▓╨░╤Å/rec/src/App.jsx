import { useState, useEffect, useRef } from 'react';
import './App.css';
import HelloWindow from './components/HelloWindow/HelloWindow';
import MyInput from './components/Input';

function App() {
  const [valueInput, setValue] = useState({first: '', second: ''})
  const [flag, setFlag] = useState(false)
  let myArr = []
  const revealRefs = useRef([]);
  revealRefs.current = []
  let sumOfFields = []
  const [fuck, setFuck] = useState(0)
  const [showError, setShowError] = useState(false)

  const handleValue = (e) => {
    const value = e.target.value;
    setValue({...valueInput, [e.target.name]: value})

    // if (isNaN(valueInput.first)) {
    //   setShowError(true)
    // } else {
    //   setShowError(false)
    // }
  }

  for (let index = 1; index < +valueInput.count + 1; index++) {
    myArr.push(index)
  }  
  
  const handleSubmit = (e) => {
    e.preventDefault()
    setFlag(!flag)
  }

  const addToRefs = (el) => {
     if(el && !revealRefs.current.includes(el)) {
       revealRefs.current.push(el)
     }
  }

  useEffect(() => {
    revealRefs.current.map(inp => sumOfFields.push(inp.value))
    let res = sumOfFields.reduce((prev, acc) => +prev * +acc, 1)
    setFuck(res)
  }, [revealRefs.current])

  return (
    <>
      <HelloWindow />
      <div className="App">
        <form>
          <MyInput value={valueInput.count} name='count' onChange={handleValue} placeholder="Введите колличество сторон" />
          {/* {showError && <div className="input-error">Not a number</div>} */}
          {
            myArr.map(i => {
              return <input className='input-size' ref={addToRefs} type="text" key={i} />
            })
          }
          <button class="button-30" role="button" onClick={handleSubmit}>submit</button>
        </form>
        <div className="result-of-sum">Результат суммы: {flag ? fuck :  0}</div>
      </div>
    </>
  );
}

export default App;
