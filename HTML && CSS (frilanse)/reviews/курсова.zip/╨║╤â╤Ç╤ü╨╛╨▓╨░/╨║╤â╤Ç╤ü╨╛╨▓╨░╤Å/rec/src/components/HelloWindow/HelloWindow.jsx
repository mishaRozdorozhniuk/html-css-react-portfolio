import React, { useState } from 'react';
import './HelloWindow.css'

const HelloWindow = () => {
  const [active, setActive] = useState(false)
  return (
    <div className={active ? 'modal active' : 'modal'}>
        <div className="modal__content" onClick={e => e.stopPropagation()}>
                      <p>Роздорожнюка Михайла</p>
                      Калькулятор для розрахунку площі багатокутників 
        </div>
        <button class="button-30" role="button"  onClick={() => setActive(!active)}>let's to calculate</button>
    </div>
  );
}

export default HelloWindow