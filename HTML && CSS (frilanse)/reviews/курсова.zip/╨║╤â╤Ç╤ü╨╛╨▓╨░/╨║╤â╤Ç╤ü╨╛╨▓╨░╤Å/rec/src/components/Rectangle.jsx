import React from 'react';

const Rectangle = ({valueInput}) => {
  return( 
  <>
    <svg width="10000" height="10000">
        <rect x="5" y="5" width={valueInput.first * 5} height={valueInput.second * 5}
        fill="skyblue" stroke="steelblue"
        />
    </svg>
  </>);
}


export default Rectangle;