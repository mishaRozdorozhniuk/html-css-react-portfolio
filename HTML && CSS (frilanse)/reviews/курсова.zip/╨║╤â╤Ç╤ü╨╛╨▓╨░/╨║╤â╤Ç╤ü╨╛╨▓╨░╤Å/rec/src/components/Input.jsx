import React from 'react'
import './Input.css'

const MyInput = ({name, type, onChange, value, placeholder}) => {
    return (
        <fieldset>
            <div class="form__group">
                <input type="text" class="form__input" value={value} name={name} type={type} onChange={onChange} placeholder={placeholder} required="" />
                <label class="form__label">{placeholder}</label>
            </div>
        </fieldset>
    )
}

export default MyInput